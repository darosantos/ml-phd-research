pyblique
========
OC1 implementation in Python.

```test.py``` features some commandline arguments to run tests with the classifier.
Run ```runtests.sh n``` to execute **n** 5-fold cross-validations in succession. Results are stored in the Results directory.
